import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import Lenis from "lenis";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
const shakerAsset = { url: "/models/grnd-shaker.glb" };

gsap.registerPlugin(ScrollTrigger, SplitText);

const clampRange = (progress: number, start: number, end: number) =>
  Math.max(0, Math.min(1, (progress - start) / (end - start)));

export function GrndShowcase() {
  const overviewRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const root = overviewRef.current;
    if (!root) return;

    if (!document.querySelector('script[data-grnd-icons]')) {
      const iconsScript = document.createElement("script");
      iconsScript.type = "module";
      iconsScript.src = "/vendor/ionicons/ionicons.esm.js";
      iconsScript.dataset["grndIcons"] = "true";
      document.body.appendChild(iconsScript);
    }

    let disposed = false;
    let model: THREE.Group | null = null;
    let modelSize: THREE.Vector3 | null = null;
    let modelCenter: THREE.Vector3 | null = null;
    let currentRotation = 0;
    let latestProgress = 0;
    let frame = 0;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setClearColor(0x000000, 0);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.NoToneMapping;
    root.querySelector(".model-container")?.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const mainLight = new THREE.DirectionalLight(0xffffff, 1);
    mainLight.position.set(1, 2, 3);
    mainLight.castShadow = true;
    mainLight.shadow.bias = -0.001;
    mainLight.shadow.mapSize.set(1024, 1024);
    scene.add(mainLight);
    const fillLight = new THREE.DirectionalLight(0xffffff, 0.5);
    fillLight.position.set(-2, 0, -2);
    scene.add(fillLight);

    const setupModel = () => {
      if (!model || !modelSize || !modelCenter) return;
      const center = modelCenter;
      const mobile = window.innerWidth < 1000;
      model.position.set(
        -center.x,
        -center.y,
        -center.z,
      );
      model.rotation.z = -THREE.MathUtils.degToRad(25);
      const maxDimension = Math.max(modelSize.x, modelSize.y, modelSize.z);
      camera.position.set(0, 0, maxDimension * (mobile ? 3.2 : 1.25));
      camera.lookAt(0, 0, 0);
    };

    const applyRotation = (progress: number) => {
      if (!model) return;
      const target = Math.PI * 12 * clampRange(progress, 0.05, 1);
      const diff = target - currentRotation;
      if (Math.abs(diff) > 0.001) {
        model.rotateOnAxis(new THREE.Vector3(0, 1, 0), diff);
        currentRotation = target;
      }
    };

    const draco = new DRACOLoader();
    draco.setDecoderPath("/vendor/draco/");
    const loader = new GLTFLoader();
    loader.setDRACOLoader(draco);
    loader.load(shakerAsset.url, (gltf) => {
      if (disposed) return;
      model = gltf.scene;
      model.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.castShadow = true;
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => {
            if (material instanceof THREE.MeshStandardMaterial) {
              material.metalness = 0.05;
              material.roughness = 0.9;
            }
          });
        }
      });
      const bounds = new THREE.Box3().setFromObject(model);
      modelSize = bounds.getSize(new THREE.Vector3());
      modelCenter = bounds.getCenter(new THREE.Vector3());
      scene.add(model);
      setupModel();
      applyRotation(latestProgress);
      root.classList.add("model-loaded");
    });

    const render = () => {
      if (disposed) return;
      renderer.render(scene, camera);
      frame = requestAnimationFrame(render);
    };
    render();

    const resize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      setupModel();
      ScrollTrigger.refresh();
    };
    window.addEventListener("resize", resize);

    const lenis = new Lenis();
    lenis.on("scroll", ScrollTrigger.update);
    const driveLenis = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(driveLenis);
    gsap.ticker.lagSmoothing(0);

    const context = gsap.context(() => {
      const headline = root.querySelector<HTMLElement>(".header-1 h1");
      if (!headline) return;
      const headlineSplit = new SplitText(headline, { type: "chars", charsClass: "char" });
      const titleSplits = Array.from(root.querySelectorAll<HTMLElement>(".tooltip .title h2")).map(
        (element) => new SplitText(element, { type: "lines", linesClass: "line" }),
      );
      const descriptionSplits = Array.from(root.querySelectorAll<HTMLElement>(".tooltip .description p")).map(
        (element) => new SplitText(element, { type: "lines", linesClass: "line" }),
      );
      [...headlineSplit.chars, ...titleSplits.flatMap((split) => split.lines), ...descriptionSplits.flatMap((split) => split.lines)].forEach((element) => {
        const span = document.createElement("span");
        while (element.firstChild) span.appendChild(element.firstChild);
        element.appendChild(span);
      });

      const header1 = root.querySelector<HTMLElement>(".header-1");
      const header2 = root.querySelector<HTMLElement>(".header-2");
      const mask = root.querySelector<HTMLElement>(".circular-mask");
      const dividers = root.querySelectorAll<HTMLElement>(".tooltip .divider");
      const tooltipTargets = [0, 1].map((index) => {
        const tooltip = root.querySelectorAll(".tooltip")[index];
        return tooltip?.querySelectorAll(".icon ion-icon, .title .line > span, .description .line > span") ?? [];
      });
      const options = { duration: 1, ease: "power3.out", stagger: 0.025 };

      ScrollTrigger.create({
        trigger: root,
        start: "75% bottom",
        onEnter: () => gsap.to(root.querySelectorAll(".header-1 h1 .char > span"), { y: "0%", ...options }),
        onLeaveBack: () => gsap.to(root.querySelectorAll(".header-1 h1 .char > span"), { y: "100%", ...options }),
      });

      ScrollTrigger.create({
        trigger: root,
        start: "top top",
        end: () => `+=${window.innerHeight * 10}px`,
        pin: true,
        pinSpacing: true,
        scrub: 1,
        invalidateOnRefresh: true,
        onUpdate: ({ progress }) => {
          latestProgress = progress;
          gsap.to(header1, { xPercent: -100 * clampRange(progress, 0.05, 0.35), overwrite: true });
          gsap.to(mask, { clipPath: `circle(${100 * clampRange(progress, 0.2, 0.3)}% at 50% 50%)`, overwrite: true });
          gsap.to(header2, { xPercent: 100 - 300 * clampRange(progress, 0.15, 0.5), overwrite: true });
          gsap.to(dividers, { scaleX: clampRange(progress, 0.45, 0.65), overwrite: true, ...options });
          tooltipTargets.forEach((targets, index) => {
            gsap.to(targets, { y: progress >= (index === 0 ? 0.65 : 0.85) ? "0%" : "125%", overwrite: true, ...options });
          });
          applyRotation(progress);
        },
      });
    }, root);

    return () => {
      disposed = true;
      gsap.ticker.remove(driveLenis);
      lenis.destroy();
      context.revert();
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(frame);
      renderer.dispose();
      draco.dispose();
      renderer.domElement.remove();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
    };
  }, []);

  return (
    <main className="grnd-page">
      <section className="intro" aria-label="Introduction">
        <h1>GRND doesn&apos;t shake.<br />It performs.</h1>
      </section>
      <section className="product-overview" ref={overviewRef} aria-label="GRND Shaker overview">
        <div className="header-1"><h1>Every Rep Starts With</h1></div>
        <div className="header-2"><h1>GRND Shaker</h1></div>
        <div className="circular-mask" />
        <div className="tooltips">
          <div className="tooltip">
            <div className="icon">{<ion-icon name="flash" />}</div>
            <div className="divider" />
            <div className="title"><h2>Built to last</h2></div>
            <div className="description"><p>Designed to match your pace, GRND runs all week on a single charge. No interruptions, no slowing down.</p></div>
          </div>
          <div className="tooltip">
            <div className="icon">{<ion-icon name="bluetooth" />}</div>
            <div className="divider" />
            <div className="title"><h2>Stay synced</h2></div>
            <div className="description"><p>With app integration, GRND helps you stay consistent. Monitor intake, set goals, and make every sip count.</p></div>
          </div>
        </div>
        <div className="model-container" aria-hidden="true" />
      </section>
      <section className="outro" aria-label="Closing statement">
        <h1>Don&apos;t Just Train — GRND</h1>
      </section>
    </main>
  );
}