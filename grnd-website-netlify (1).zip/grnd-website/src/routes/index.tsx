import { createFileRoute } from "@tanstack/react-router";
import { GrndShowcase } from "@/components/GrndShowcase";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GRND Shaker — Every Rep Starts With GRND" },
      { name: "description", content: "Meet the GRND Shaker. Built to last, made to stay synced, and designed to perform through every rep." },
      { property: "og:title", content: "GRND Shaker — Every Rep Starts With GRND" },
      { property: "og:description", content: "A scroll-driven look at the GRND Shaker, built to last and made to stay synced." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GrndShowcase,
});
